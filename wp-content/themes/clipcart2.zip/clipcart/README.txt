Clip Cart Child Theme
http://themedy.com/

-----------------------------------------

<b>** INSTALLING THIS CHILD THEME **</b>

We recommend using the Cart66 plugin with this eCommerce theme. Find out more information about Cart66 here: http://themedy.com/recommends/Cart66/

Please check out our general online documentation for more info on how to install and use our themes: http://themedy.com/usermanual/


<b>** USING THIS CHILD THEME **</b>

Check out the Clip Cart support thread for additional info on how to use this child theme and to ask any questions: http://themedy.com/forum/discussion/284/clip-cart-documentation

-----------------------------------------

<b>CHANGELOG</b>

v1.5.1
- Added support for Cart66 Cloud
- Translation fixes

v1.5
- Updated products template functionality
- Updated admin CSS / Icons
- Updated theme screenshot
- Updated TGM Plugin files
- Updated depreceated WooCommerce code

v1.4.3
- Responsive fixes for Cart66 and WooCommerce cart/checkout.

v1.4.2
- Fixed chrome input styling issue
- Fixed slider image issue

v1.4.1
- Updates to related/upsells after product list
- Added default Woo image sizes
- Better mobile css for Woo product info page

v1.4
- Updates & Fixes for Genesis 2.0
- HTML5 ready
- New header image control and output using <img>
- Fixed product category names
- Fixed widget admin styles
- Fixed thumbnail names and deprecated functions
- Properly added translation support for TGM plugins control
- Properly enqueued default styles
- Added proper products thumbnail control for WooCommerce
- General updates for WooCommerce
- Fixed WP Debug errors
- Removed custom.css option (will still load file if exists)

v1.3.4
- Fixing some checkout display issues on iPhone and Authorize.net

v1.3.3
- Some fixes for WooCommerce 2.0
- Responsive landing page template and fix
- Admin page adjustments
- Translation additions for slides

v1.3.2
- Fix for styles and Genesis 1.9

v1.3.1
- Fix meta box not showing up on products URL change

v1.3
- Clip Cart is now fully responsive!
- Added plugin support for WooCommerce! (http://woothemes.com/woocommerce)	
- Updated products and slides admin icons
- CSS Support for Navigation extras
- General CSS and PHP cleanup

v1.2.4
- Fix homepage products not showing if the post type has been renamed.

v1.2.3
- Add "hide" to image caption in gallery tab to have it not show.

v1.2.2
- Missed typo with categories

v1.2.1
- Fix PRODUCTS typo

v1.2
- Remove secondary nav option since it's not used in the theme by default
- Add support for WordPress 3.4 features
- Categories permalinks issue fixed and add flush added on theme load
- Add easier way to change the name of "Products" - look in lib/init.php for variables

v1.1.3
- Fixed blank screen on Cart66 shortcode popup (requires latest version of cart66)

v1.1.2
- TGM plugin fix for WP 3.4
- Some more Localization

v1.1.1
- Options page for WPMS fixed
- Float right added to Nav for Genesis 1.8

v1.1
- Updated options to work with WordPress 3.3 (again)
- Moved short codes to plugin (http://themedy.com/recommends/themedy-visual-designer/)
- Options panel link moved to WordPress Appearance menu
- Better Localization

v1.0
- First release... Enjoy!