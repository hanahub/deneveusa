<?php
/*----------------------------------------------------------

Description: 	eCommerce functionality for Themedy themes

----------------------------------------------------------*/

// New Image Sizes
add_image_size('product-thumb', 190, 190, TRUE);
add_image_size('gallery-thumb', 96, 96, TRUE);

// Check For Shop Plugins
function themedy_active_plugin(){
	$active_plugins = get_option('active_plugins');
	$plugin_name = '';

	if ( in_array( 'shopp/Shopp.php',$active_plugins ) || in_array( 'Shopp.php',$active_plugins ) ) $plugin_name = 'shopp';
	elseif ( in_array( 'woocommerce/woocommerce.php',$active_plugins ) ) $plugin_name = 'woocommerce';
	elseif ( in_array( 'wp-e-commerce/wp-shopping-cart.php',$active_plugins ) ) $plugin_name = 'wp_ecommerce';
	elseif ( in_array( 'eshop/eshop.php',$active_plugins ) || in_array( 'eshop.php',$active_plugins ) ) $plugin_name = 'eshop';
	elseif ( in_array( 'cart66-cloud/cart66-cloud.php',$active_plugins ) ) $plugin_name = 'cart66_cloud';
	elseif ( in_array( 'cart66-lite/cart66.php',$active_plugins ) || in_array( 'cart66/cart66.php',$active_plugins ) || in_array( 'cart66-pro/cart66.php',$active_plugins ) )	$plugin_name = 'cart66';
	elseif ( in_array( 'wordpress-simple-paypal-shopping-cart/wp_shopping_cart.php',$active_plugins ) ) $plugin_name = 'wp_simple_paypal_sc';

	return ( $plugin_name <> '' ) ? $plugin_name : false;
}
global $themedy_active_plugin_name;
$themedy_active_plugin_name = themedy_active_plugin();

// Currency Symbol
function themedy_get_currency_sign() {
	global $themedy_active_plugin_name;

	if ($themedy_active_plugin_name == 'cart66_cloud') {
		$currency_sign = '';
	}
	elseif ($themedy_active_plugin_name == 'cart66') {
		$currency_sign = defined('CART66_CURRENCY_SYMBOL') ? CART66_CURRENCY_SYMBOL : CURRENCY_SYMBOL;
	}
	elseif ($themedy_active_plugin_name == 'woocommerce') {
		$currency_sign = get_woocommerce_currency_symbol();
	}
	else {
		$currency_sign = themedy_get_option('currency_sign');
	}

	return $currency_sign;
}

// Displayed Prices
function themedy_get_price() {
	global $post, $themedy_active_plugin_name, $wpdb;
	$price = 0;
	if ($themedy_active_plugin_name == 'cart66_cloud') {
		$price = do_shortcode('[cc_product_price sku="'.get_post_meta($post->ID,'cart66_product_id',true).'"]');
	}
	elseif ($themedy_active_plugin_name == 'cart66') {
		$cart66_tablename = Cart66Common::getTableName('products');
		$results = $wpdb->get_results($wpdb->prepare("SELECT price FROM $cart66_tablename WHERE item_number = %s", get_post_meta($post->ID,'cart66_product_id',true)));
		if ( $results ) $price = $results[0]->price;
	}
	else {
		$price = get_post_meta($post->ID, 'product_price', true);
		if (empty($price)) { $price = 0; }
	}
	return $price;
}

// Products Post Type
if ($themedy_active_plugin_name != 'woocommerce') {
	add_action('init','themedy_create_product_init');
}
function themedy_create_product_init()  {
	$labels = array
	(
		'name' => _x(PRODUCTS_LABEL, 'post type general name', 'themedy'),
		'singular_name' => _x(PRODUCT_LABEL, 'post type singular name', 'themedy'),
		'add_new' => _x('Add New', PRODUCT_LABEL, 'themedy'),
		'add_new_item' => __('Add New '.PRODUCT_LABEL, 'themedy'),
		'edit_item' => __('Edit '.PRODUCT_LABEL, 'themedy'),
		'new_item' => __('New '.PRODUCT_LABEL, 'themedy'),
		'view_item' => __('View '.PRODUCT_LABEL, 'themedy'),
		'search_items' => __('Search '.PRODUCTS_LABEL, 'themedy'),
		'not_found' =>  __('No '.PRODUCTS_LABEL.' found', 'themedy'),
		'not_found_in_trash' => __('No '.PRODUCTS_LABEL.' found in Trash', 'themedy'),
		'parent_item_colon' => ''
	);
	$support = array
	(
		'title',
		'editor',
		'author',
		'thumbnail',
		'custom-fields',
		'comments',
		'genesis-seo',
		'genesis-layouts',
		'revisions',
		'excerpt'
	);
	$args = array
	(
		'labels' => $labels,
		'public' => TRUE,
		'has_archive' => TRUE,
		'_builtin' => FALSE,
		'rewrite' => array('slug'=>'','with_front'=>false),
		'capability_type' => 'post',
		'hierarchical' => FALSE,
		'query_var' => true,
		'supports' => $support,
		'taxonomies' => array(PRODUCTS_CATEGORY_NAME),
		'show_in_nav_menus' => FALSE,
		'menu_position' => 5
	);
	register_post_type(PRODUCTS_NAME,$args);
	$labels = array
	(
	'name' => _x( 'Product Categories', 'taxonomy general name', 'themedy' ),
	'menu_name' => __( 'Categories', 'themedy' ),
	);
	register_taxonomy(
        PRODUCTS_CATEGORY_NAME,
        PRODUCTS_NAME,
        array(
            'hierarchical' => TRUE,
            'labels' => $labels,
            'query_var' => TRUE,
            'rewrite' => array('slug'=>'/'.PRODUCTS_CATEGORY_NAME,'with_front'=>false),
        )
    );
}

// Flush rewrite rules for custom post types.
add_action( 'load-themes.php', 'themedy_flush_rewrite_rules' );

// Flush rewrite rules.
function themedy_flush_rewrite_rules() {
	global $pagenow, $wp_rewrite;

	if ( 'themes.php' == $pagenow && isset( $_GET['activated'] ) )
		$wp_rewrite->flush_rules();
}

// Filter to include the Cart66 dialog box on additional screen ids
add_filter('cart66_add_popup_screens', 'themedy_custom_popups');
function themedy_custom_popups(){
  return array(PRODUCTS_NAME);
}

// Add Product Post Type Template
add_filter( 'template_include', 'themedy_template_include' );
function themedy_template_include( $template ) {
    if ( get_query_var('post_type') == PRODUCTS_NAME ) { // Product Single
        if ( is_single() ) {
            if ( $single = locate_template( array( 'page_product_single.php') ) )
                return $single;
        } elseif (is_archive()) {
			if ( $archive = locate_template( array( 'page_products.php') ) )
				return $archive;
		}
    }
	elseif ( is_tax(PRODUCTS_CATEGORY_NAME) ) { // Product Categories
		return locate_template( array(
			'page_products.php',
			'index.php'
		));
    }
    return $template;
}

// Product Archives Navigation Fix
add_filter('query_string', 'themedy_tax_change');
function themedy_tax_change($query_string) {
	if (stristr($query_string, PRODUCTS_CATEGORY_NAME.'=') or stristr($query_string, 'post_type='.PRODUCTS_NAME) ) {
		$query_string = $query_string.'&posts_per_page='.themedy_get_option('product_limit');
	}
	return $query_string;
}

// Add Custom Columns to Products
add_filter( 'manage_edit-products_columns', 'themedy_edit_products_columns' ) ;
function themedy_edit_products_columns( $columns ) {

	global $themedy_active_plugin_name;
	if ($themedy_active_plugin_name == 'cart66' || $themedy_active_plugin_name == 'cart66_cloud') {
		$columns = array(
			'cb' => '<input type="checkbox" />',
			'title' => __( 'Product', 'themedy' ),
			'author' => __( 'Author', 'themedy' ),
			'product_categories' => __( 'Categories', 'themedy' ),
			'cart66_id' => __( 'Cart66 ID', 'themedy' ),
			'date' => __( 'Date', 'themedy' )
		);
	} else {
		$columns = array(
			'cb' => '<input type="checkbox" />',
			'title' => __( 'Product', 'themedy' ),
			'author' => __( 'Author', 'themedy' ),
			'product_categories' => __( 'Categories', 'themedy' ),
			'date' => __( 'Date', 'themedy' )
		);
	}

	return $columns;
}

add_action( 'manage_products_posts_custom_column', 'themedy_manage_product_columns', 10, 2 );
function themedy_manage_product_columns( $column, $post_id ) {
	global $post;
	switch( $column ) {

		case 'product_categories' :
			$terms = get_the_terms( $post_id, PRODUCTS_CATEGORY_NAME );
			if ( !empty( $terms ) ) {
				$out = array();
				foreach ( $terms as $term ) {
					$out[] = sprintf( '<a href="%s">%s</a>',
						esc_url( add_query_arg( array( 'post_type' => $post->post_type, PRODUCTS_CATEGORY_NAME => $term->slug ), 'edit.php' ) ),
						esc_html( sanitize_term_field( 'name', $term->name, $term->term_id, PRODUCTS_CATEGORY_NAME, 'display' ) )
					);
				}
				echo join( ', ', $out );
			}
			else {
				_e( 'No Categories', 'themedy' );
			}
			break;

		case 'cart66_id' :
			$cart66_id = get_post_meta( $post_id, 'cart66_product_id', true );
			echo $cart66_id;
			break;

		default :
			break;
	}
}

add_filter( 'manage_edit-products_sortable_columns', 'themedy_product_sortable_columns' );
function themedy_product_sortable_columns( $columns ) {
	$columns['cart66_id'] = 'cart66_id';

	return $columns;
}

add_action( 'load-edit.php', 'themedy_edit_products_load' );
function themedy_edit_products_load() {
	add_filter( 'request', 'themedy_sort_products' );
}

function themedy_sort_products( $vars ) {
	if ( isset( $vars['post_type'] ) && 'products' == $vars['post_type'] ) {
		if ( isset( $vars['orderby'] ) && 'cart66_id' == $vars['orderby'] ) {
			$vars = array_merge(
				$vars,
				array(

					'meta_key' => 'cart66_product_id',
					'orderby' => 'meta_value_num'

				)
			);
		}
	}

	return $vars;
}

// Add Meta Boxes
 add_action('admin_menu', 'add_themedy_options_meta_box');
function add_themedy_options_meta_box() {
	add_meta_box( 'themedy_options', 'Themedy '.__('Options', 'themedy').'', 'themedy_options', PRODUCTS_NAME, 'side', 'core' );
}

function themedy_options() {
	global $post;
	echo '<input type="hidden" name="themedy_options_noncename" id="themedy_options_noncename" value="' . wp_create_nonce( plugin_basename(__FILE__) ) . '" />';
	$cart66_id = get_post_meta($post->ID, 'cart66_product_id', true);
	$product_price = get_post_meta($post->ID, 'product_price', true);

	global $themedy_active_plugin_name;
	if ($themedy_active_plugin_name == 'cart66' || $themedy_active_plugin_name == 'cart66_cloud') {
		echo '<p><strong>'.__('Cart66 Product Number or SKU', 'themedy').': </strong>';
		echo '<input type="text" style="" size="10" id="cart66_product_id" name="cart66_product_id" value="' . $cart66_id . '">';
	} else {
		echo '<p><strong>Price: </strong>';
		echo '<input type="text" style="" size="10" id="product_price" name="product_price" value="' . $product_price . '">';
		echo '<br /><small><a href="http://themedy.com/recommends/Cart66/">Cart66</a> plugin is not active- enter a custom price above</small></p>';
	}
}
add_action('save_post', 'themedy_save_postdata', 1, 2); // save the custom fields
function themedy_save_postdata( $post_id ) {
   	global $post, $themedy_active_plugin_name;

	if (isset( $_POST['cart66_product_id'] ) and ($themedy_active_plugin_name == 'cart66' || $themedy_active_plugin_name == 'cart66_cloud') ) {
    	update_post_meta( $post_id, 'cart66_product_id', strip_tags( $_POST['cart66_product_id'] ) );
	}

	if (isset( $_POST['product_price'] ) ) {
		update_post_meta( $post_id, 'product_price', strip_tags( $_POST['product_price'] ) );
	}
}