<?php
// So we have proper sidebars
remove_action('genesis_loop', 'genesis_do_loop');
add_action('genesis_loop', 'woocommerce_content');

remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );
remove_action( 'genesis_sidebar_alt', 'genesis_do_sidebar_alt' );
add_action( 'genesis_sidebar', 'themedy_do_product_sidebar' );
add_action( 'genesis_sidebar_alt', 'themedy_do_product_sidebar_alt' );

genesis();