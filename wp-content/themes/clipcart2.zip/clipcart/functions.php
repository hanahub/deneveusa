<?php
require_once(TEMPLATEPATH.'/lib/init.php'); // Start Genesis Engine
require_once(STYLESHEETPATH.'/lib/init.php'); // Start Themedy Options

add_theme_support( 'html5' );
add_theme_support( 'woocommerce' );

// Add Woo Sizes
global $pagenow;
if ( is_admin() && isset( $_GET['activated'] ) && $pagenow == 'themes.php' ) add_action( 'init', 'themedy_woocommerce_image_dimensions', 1 );
function themedy_woocommerce_image_dimensions() {
  	$catalog = array(
		'width' 	=> '240',	// px
		'height'	=> '240',	// px
		'crop'		=> 1 		// true
	);
 
	$single = array(
		'width' 	=> '435',	// px
		'height'	=> '435',	// px
		'crop'		=> 1 		// true
	);
 
	$thumbnail = array(
		'width' 	=> '135',	// px
		'height'	=> '135',	// px
		'crop'		=> 1 		// true
	);
 
	// Image sizes
	update_option( 'shop_catalog_image_size', $catalog ); 		// Product category thumbs
	update_option( 'shop_single_image_size', $single ); 		// Single product image
	update_option( 'shop_thumbnail_image_size', $thumbnail ); 	// Image gallery thumbs
}

// Change columns in related products output to 3 and move below the product summary
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20);
add_action( 'woocommerce_after_single_product', 'woocommerce_output_related_products', 20);

if (!function_exists('woocommerce_output_related_products')) {
	function woocommerce_output_related_products() {
	    woocommerce_related_products(array(3,3)); // 3 products, 3 columns
	}
}

// Change columns in upsells output to 3 and move below the product summary
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );
add_action( 'woocommerce_after_single_product_summary', 'woocommerceframework_upsell_display', 15);

if (!function_exists('woocommerceframework_upsell_display')) {
	function woocommerceframework_upsell_display() {
	    woocommerce_upsell_display(3,3); // 3 products, 3 columns
	}
}

// Add WP Background Image Support
add_theme_support( 'custom-background', array(
	'default-color' => 'fff',
	'default-image' => get_stylesheet_directory_uri() . '/images/bg-body.png'
) );

// Add WP Header Image Support
add_theme_support( 'custom-header', array(
	'default-image'			=> get_stylesheet_directory_uri() . '/images/header.png',
	'default-text-color'	=> '333',
	'flex-width'        	=> true,
	'width'					=> 230,
	'flex-height'       	=> true,
	'height'				=> 80,
	'wp-head-callback'		=> 'header_style',
	'admin-head-callback'	=> 'admin_header_style'
) );

function header_style() {
	$text_color = get_theme_mod( 'header_textcolor', get_theme_support( 'custom-header', 'default-text-color' ) );
	if ( get_header_textcolor() != 'blank' )
		echo "<style type= \"text/css\">.title-area .site-title a { color: #$text_color }</style>\n";
}

function admin_header_style() {
	echo '<style type="text/css"> #headimg { width: '.get_custom_header()->width.'px; height: '.get_custom_header()->height.'px; background-repeat: no-repeat; } #headimg h1 { margin: 0; } #headimg h1 a { text-decoration: none; display: block; padding: 0.5em 0; background: #fff; } #headimg #desc { background: #fff; height: '.get_custom_header()->height.'px; color: #333 !important; }</style>';
}

// Header Image Output Control
if ( get_header_textcolor() == 'blank' ) {
	remove_action( 'genesis_site_title', 'genesis_seo_site_title' );
	remove_action( 'genesis_site_description', 'genesis_seo_site_description' );
	add_action( 'genesis_site_title', 'custom_site_title' );
	function custom_site_title() { 
		$header_image = esc_url( get_header_image());	
		if (!empty($header_image))
		echo 
		"<div class=\"site-title logo\"><a href=\"", esc_url(home_url()), "\">\n",
		"<img width=\"", get_custom_header()->width, "\" height=\"", get_custom_header()->height, "\" src=\"", $header_image, "\" alt=\"", get_bloginfo('title'), "\" />\n",
		"</a></div>";
	}
}

// Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

// Add our styles and scripts
add_action('wp_enqueue_scripts', 'themedy_load_scripts');
function themedy_load_scripts() {
	if (themedy_get_option('style') != 'default') wp_enqueue_style('themedy-child-theme-style', STYLES_URL.'/'.themedy_get_option('style').'.css',CHILD_THEME_NAME,CHILD_THEME_VERSION,'screen');
	if (is_file(CHILD_DIR.'/custom/custom.css')) wp_enqueue_style('themedy-child-theme-custom-style', CHILD_URL.'/custom/custom.css',CHILD_THEME_NAME,CHILD_THEME_VERSION,'screen');
	if (themedy_get_option('mobile_menu')) wp_enqueue_script('mobile_menu', CHILD_THEME_LIB_URL.'/js/jquery.mobilemenu.js', array('jquery'), '1.0', FALSE);
}

// Viewport scale (iPhone)
add_action('genesis_meta','themedy_viewport_meta');
function themedy_viewport_meta() {
	echo "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0\" />\n";
}

// Remove Header Widget Area
unregister_sidebar( 'header-right' );

// Remove the Secondary Nav option
add_theme_support( 'genesis-menus', array( 'primary' => 'Primary Navigation Menu' ) );

// Add the Nav Above Header
remove_action('genesis_after_header', 'genesis_do_nav');
add_action('genesis_header', 'genesis_do_nav');

// No Secondary Nav
remove_action('genesis_after_header', 'genesis_do_subnav');

// Breadcrumbs / Search area after header
remove_action('genesis_before_loop', 'genesis_do_breadcrumbs'); // Remove Breadcrumbs by default
add_action('genesis_after_header','themedy_secondary_area');
function themedy_secondary_area() { ?>
	<div id="secondary_area">
    	<div class="wrap">
        	<?php if (is_front_page()) {  ?>
                <p class="homepage_tag"><?php echo themedy_option('homepage_breadcrumb_text'); ?></p>
            <?php } else { ?>
				<div class="breadcrumb_wrap">
                    <?php genesis_do_breadcrumbs(); ?>
                </div>
			<?php } ?>
            <div id="search_area">
            	<form method="get" class="search_form" action="<?php echo home_url(); ?>">
                    <p>
                    <input class="text_input" type="text" value="<?php echo __('To search, type and hit enter...', 'themedy'); ?>" name="s" id="s" onfocus="if (this.value == '<?php echo __('To search, type and hit enter...', 'themedy'); ?>') {this.value = '';}" onblur="if (this.value == '') {this.value = '<?php echo __('To search, type and hit enter...', 'themedy'); ?>';}" />
                    <input type="hidden" id="searchsubmit" value="Search" />
                    </p>
        		</form>
            </div>
        </div>
    </div>
<?php
}

// Breadcrumbs Customization
add_filter( 'genesis_breadcrumb_args', 'themedy_breadcrumb_args' );
function themedy_breadcrumb_args( $args ) {
    $args['home']                    = 'Home';
    $args['sep']                     = '</div><div class="crumb">';
    $args['list_sep']                = ', '; // Genesis 1.5 and later
    $args['prefix']                  = '<div class="breadcrumb">';
    $args['suffix']                  = '</div></div>';
    $args['labels']['prefix']        = '<div class="crumb crumb_home">';
    $args['labels']['author']        = 'Archives for ';
    $args['labels']['category']      = 'Archives for '; // Genesis 1.6 and later
    $args['labels']['tag']           = 'Archives for ';
    $args['labels']['date']          = 'Archives for ';
    $args['labels']['search']        = 'Search for ';
    $args['labels']['tax']           = '';
    $args['labels']['post_type']     = '';
    $args['labels']['404']           = ''; // Genesis 1.5 and later
    return $args;
}

// Product Sidebar 1
function themedy_do_product_sidebar() {
	if ( !dynamic_sidebar('primary-product-sidebar') ) {

		echo '<div class="widget widget_text"><div class="widget-wrap">';
			echo '<h4 class="widgettitle">';
				_e('Primary Product Sidebar', 'themedy');
			echo '</h4>';
			echo '<div class="textwidget"><p>';
				printf(__('This is the Primary Product Sidebar. You can add content to this area by visiting your <a href="%s">Widgets Panel</a> and adding new widgets to this area.', 'genesis'), admin_url('widgets.php'));
			echo '</p></div>';
		echo '</div></div>';

	}
}

// Product Sidebar 2
function themedy_do_product_sidebar_alt() {
	if ( !dynamic_sidebar('secondary-product-sidebar') ) {

		echo '<div class="widget widget_text"><div class="widget-wrap">';
			echo '<h4 class="widgettitle">';
				_e('Secondary Product Sidebar', 'themedy');
			echo '</h4>';
			echo '<div class="textwidget"><p>';
				printf(__('This is the Secondary Product Sidebar. You can add content to this area by visiting your <a href="%s">Widgets Panel</a> and adding new widgets to this area.', 'genesis'), admin_url('widgets.php'));
			echo '</p></div>';
		echo '</div></div>';

	}
}

// Add Footer Menu
add_action('genesis_footer','themedy_footer_menu');
function themedy_footer_menu() { ?>
		<div class="footer_menu">
        	<?php
        	if (function_exists('wp_nav_menu')) {
				wp_nav_menu(array(
					'theme_location' => 'footer',
					'container' => 'div',
					'menu_class' => 'menu footer-nav',
					'fallback_cb' => 0
				));
			}
			?>
        </div>
<?php }
register_nav_menu('footer', __('Footer Menu', 'themedy'));

// Customizes Footer Text (set in options)
if (themedy_get_option('footer')) {
	add_filter('genesis_footer_creds_text', 'custom_footer_creds_text');
	function custom_footer_creds_text($creds) {
    	$creds = themedy_get_option('footer_text');
    return $creds;
	}
}

// Register Sidebars
genesis_register_sidebar(array(
	'name' => 'Primary Product Sidebar',
	'id' => 'primary-product-sidebar',
	'description' => 'This is the primary product sidebar shown on product pages.',
));
genesis_register_sidebar(array(
	'name' => 'Secondary Product Sidebar',
	'id' => 'secondary-product-sidebar',
	'description' => 'This is the secondary product sidebar shown on product pages.',
));
genesis_register_sidebar(array(
	'name' => 'Homepage Widget Area 1',
	'id' => 'home-sidebar-1',
	'description' => 'This is sidebar 1 on the homepage.',
	'before_widget' =>  '<div id="%1$s" class="widget %2$s">',
	'after_widget' =>  '</div>',
	'before_title' => '<h4>',
	'after_title' => '</h4>'
));
genesis_register_sidebar(array(
	'name' => 'Homepage Widget Area 2',
	'id' => 'home-sidebar-2',
	'description' => 'This is sidebar 2 on the homepage.',
	'before_widget' =>  '<div id="%1$s" class="widget %2$s">',
	'after_widget' =>  '</div>',
	'before_title' => '<h4>',
	'after_title' => '</h4>'
));

if (is_file(CHILD_DIR.'/custom/custom_functions.php')) { include(CHILD_DIR.'/custom/custom_functions.php'); } // Include Custom Functions